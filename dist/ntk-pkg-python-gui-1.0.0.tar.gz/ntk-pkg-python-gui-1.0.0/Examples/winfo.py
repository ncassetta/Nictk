# This file is part of Ntk - A simple tkinter wrapper.
#    Copyright (C) 2021  Nicola Cassetta
#    See <https://github.com/ncassetta/Ntk>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the Lesser GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.


import _setup           # allows import from parent folder
from Ntk import *

winfo_options = ["atom", "atomname", "cells", "children", "class", "colormapfull", "containing", 
                 "depth", "exists", "fpixels", "geometry", "height", "id", "interps", "ismapped",
                 "manager", "name", "parent", "pathname", "pixels", "pointerx", "pointerxy",
                 "pointery", "reqheight", "reqwidth", "rgb", "rootx", "rooty", "screen", "screencells",
                 "screendepth", "screenheight", "screenmmheight", "screenmmwidth", "screenvisual",
                 "screenwidth", "server", "toplevel", "viewable", "visual", "visualid", "visualsavailable",
                 "vrootheight", "vrootwidth", "vrootx", "vrooty", "width", "x", "y"]

winMain = NtkMain(100, 100, 800, 600, title="winfo demo")
labTest = NtkLabel(winMain, 0, 0, "fill", 50, pad=(30, 10, 30, 10), content="labTest")
txtTest = NtkText(winMain, 0, "pack", "fill", "fill", pad=(30, 5, 30, 10))

for opt in winfo_options:
    try:
        output = labTest.get_winfo(opt)
    except TypeError:
        output = "NEEDS PARAM    "
    desc = "{:40}{:>30}".format('labTest.get_winfo("' + opt + '")', str(output))
    txtTest.append_text(desc + "\n")

mainloop()
