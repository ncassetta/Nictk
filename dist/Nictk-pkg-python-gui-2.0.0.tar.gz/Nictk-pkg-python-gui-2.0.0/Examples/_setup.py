# Importing this file allows example files to import Ntk without the need to
# install it. 
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
