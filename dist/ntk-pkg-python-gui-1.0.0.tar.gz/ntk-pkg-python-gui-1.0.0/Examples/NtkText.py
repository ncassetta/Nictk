# This file is part of Ntk - A simple tkinter wrapper.
#    Copyright (C) 2021  Nicola Cassetta
#    See <https://github.com/ncassetta/Ntk>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the Lesser GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.


import _setup           # allows import from parent folder
from Ntk import *

times = 0

def changed_callback():
    times += 1
    lab1.set_content("Changed " + str(times) + " times")

winMain = NtkMain(100, 100, 800, 600, "Prova NtkText widget")
winMain.config_children("all", font=("Arial", 12))
vfr1 = NtkVerFrame(winMain, 0, 0, '80%', '80%')
lab1 = NtkLabel(vfr1, 10, 10, 'fill', 50, pad=(5, 5), content="Ntk text")
txt1 = NtkText(vfr1, 10, 'pack', 'fill', 'fill', pad=(5, 5))
txt1.tag_add(ALL, '0.1', END)
txt1.tag_bind(ALL,"<<ChangedVar>>", func=changed_callback)


winMain.mainloop()